import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Menu, X } from 'lucide-react';

export default function Navbar() {
  const [location] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  const navLinks = [
    { href: '/', label: 'Home' },
    { href: '/about', label: 'About' },
    { href: '/plans', label: 'Plans' },
    { href: '/shop', label: 'Shop' },
    { href: '/contact', label: 'Contact' },
  ];

  const isActive = (href: string) => {
    if (href === '/') return location === '/';
    return location.startsWith(href);
  };

  const title = "VeriHealth";

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 backdrop-blur-sm bg-white/95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Left-aligned Animated Logo/Title */}
          <Link href="/">
            <div className="flex items-center cursor-pointer group hover:scale-[1.02] active:scale-[0.98] transition-transform duration-200">
              <span className="text-2xl font-bold font-heading relative overflow-hidden">
                {title.split('').map((letter, i) => (
                  <span
                    key={i}
                    className="animated-letter inline-block"
                    style={{
                      animationDelay: `${i * 0.08}s`,
                      opacity: isLoaded ? 1 : 0,
                    }}
                  >
                    {letter}
                  </span>
                ))}
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`text-sm font-medium transition-colors cursor-pointer ${
                    isActive(link.href)
                      ? 'text-medical-blue-600'
                      : 'text-gray-600 hover:text-medical-blue-600'
                  }`}
                >
                  {link.label}
                </span>
              </Link>
            ))}
            <Link href="/portal">
              <button className="px-5 py-2 bg-medical-blue-600 text-white rounded-lg text-sm font-medium hover:bg-medical-blue-700 transition-colors">
                Clinician Portal
              </button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6 text-gray-900" />
            ) : (
              <Menu className="h-6 w-6 text-gray-900" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col gap-2">
              {navLinks.map((link) => (
                <Link key={link.href} href={link.href}>
                  <span
                    className={`block px-4 py-2 rounded-lg text-sm font-medium cursor-pointer ${
                      isActive(link.href)
                        ? 'bg-medical-blue-50 text-medical-blue-600'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {link.label}
                  </span>
                </Link>
              ))}
              <Link href="/portal">
                <button
                  className="w-full mt-2 px-4 py-2 bg-medical-blue-600 text-white rounded-lg text-sm font-medium hover:bg-medical-blue-700 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Clinician Portal
                </button>
              </Link>
            </div>
          </div>
        )}
      </div>
      
      {/* CSS for letter animations */}
      <style>{`
        @keyframes letterSlideIn {
          0% {
            opacity: 0;
            transform: translateY(20px);
          }
          100% {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes gradientShift {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        
        .animated-letter {
          background: linear-gradient(90deg, #2563eb, #0891b2, #7c3aed, #2563eb);
          background-size: 300% 100%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: 
            letterSlideIn 0.5s ease-out forwards,
            gradientShift 4s ease infinite;
        }
      `}</style>
    </nav>
  );
}
